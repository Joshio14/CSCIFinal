#include <iostream>

using namespace std;

struct Node
{
    int key;
    Node* next;
};

class LL
{
    private:
        Node* head;
    public:
        LL() {head = NULL;}
        void insert(int n);
        void search(int v);
        void display();
};

void LL::insert(int n)
{
    Node* add = new Node();
    add->key = n;
    add->next = nullptr;

    if(head == NULL) head = add;
    else
    {
        Node* temp = head;
        while(temp->next != NULL)
        {
            temp = temp->next;
        }
        temp->next = add;
    }
    
}

void LL::search(int v)
{
    if (head->key == v) {cout << "Node is the head value." << endl;}
    else
    {
        Node* temp = head->next;
        int counter = 1;
        while (temp != NULL)
        {
            if (temp->key == v) {cout << "Node found at index " << counter << "." << endl; return;}
            temp = temp->next;
            counter++;
        }
        cout << "Value not found." << endl;
    }
}

void LL::display()
{
    if (head == NULL)
    {
        cout << "No data stored." << endl;
    }
    else
    {
        Node* temp = head;
        while (temp != NULL)
        {
            cout << temp->key << " -> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
    
}

int main(int argc, char* argv[])
{
    LL linked;
    linked.insert(10);
    linked.insert(5);
    linked.insert(2);
    linked.insert(7);
    linked.display();
    linked.search(11);
}