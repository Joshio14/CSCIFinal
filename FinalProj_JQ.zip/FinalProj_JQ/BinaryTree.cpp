#include <iostream>

using namespace std;

struct Node
{
    int key;
    Node* left;
    Node* right;
};

class BST
{
    public:
        Node* root;
        int count;
    
        void insert(int val);
        void search(int val);
        void display();
};

void BST::insert(int val)
{
    Node* add = new Node(); add->key = val;
    add->right = NULL; add->left = NULL;

    if (root == NULL) {root = add; return;}

    else
    {
        Node* parent = NULL, *temp = root;
        while(temp != NULL)
        {
            parent = temp;
            if (add->key < temp->key)
            {
                temp = temp->left;
            }
            else
            {
                temp = temp->right;
            }
        }
        if (parent->key < add->key)
        {
            parent->right = add;
        }
        else
        {
            parent->left = add;
        }
        
    }
    
}

void BST::search(int val)
{
    Node* temp = root->right;
    if (temp == NULL)
    {
        cout << "NULL";
    }
    else
    {
        cout << temp->key;
    }
    cout << endl;
}

void printHelper(Node* curr, int space, int count)
{
    if (curr == nullptr) return;

    space += count;

    printHelper(curr->right, space+count, count);
    cout << "\n";
    for (int i = count; i < space; i++) cout << " ";
    cout << curr->key;
    cout << "\n";
    printHelper(curr->left, space+count, count);
}

void BST::display()
{
    printHelper(root, 0, 10);
}


int main(int agrc, char* argv[])
{
    BST tree;

    tree.insert(10);
    tree.insert(4);
    tree.insert(2);
    tree.insert(5);
    tree.insert(11);

    tree.display();
}